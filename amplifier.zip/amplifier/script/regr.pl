#!/usr/bin/perl -w
#******************************************************************************
#   Copyright   : xbj Reserved
#   File        : regr.pl
#   Author      : xbj 
#   Modified    : 22-12-19 Created
#******************************************************************************
#
$run     =shift @ARGV;
$list    =shift @ARGV;
$lsf_max =shift @ARGV;

$option ="";
if(int(@ARGV) >0 ){
$option =shift @ARGV;
}
my $testname="";

my @tests_to_run =();

my $total_ttest_num=0;

open(FIN,"<$list");
while(<FIN>){
    chomp;
    my $line=$_;
    if($line=~/^(\w+)/){
        $testname =$1;
        push @tests_to_run,$testname;
        print "Get test:$testname\n";
        $total_ttest_num++;
    }
}
close(FIN);

my $left_test_num=$total_ttest_num;

foreach my$tests_to_run (@tests_to_run){
    $testname=$tests_to_run;
    #my $lsf_ok = &check_lsf($lsf_max);
    #while(!$lsf_ok){
    #        $lsf_ok = &check_lsf($lsf_max);
    #}
    &sub_job();
    $left_test_num--;

}

#my @lice_fail =&get_licensed_failed();
#push @tests_to_run,@lice_fail;

#####################################################################

sub lsf_num{
    my $lsf_num_simv    =`bjobs -l|grep simv |wc -l`;
    my $lsf_num_vlogan  =`bjobs -l|grep vlogan |wc -l`;
    my $lsf_num_vcs     =`bjobs -l|grep vcs |wc -l`;
    return (int($lsf_num_simv)+int($lsf_num_vlogan)+int($lsf_num_vcs));
}

sub run_test{
    my $test=shift @_;
    my $option =shift@_;
    system "python3  $ENV{WORKAREA}/script/xbj.py $run -t $test $option  >/dev/null &";
    print "run test: python3  $ENV{WORKAREA}/script/xbj.py $run -t $test $option &\n";
}

sub check_lsf{
    my $lsf_max     =shift @_;
    my $cur_lsf_num =&lsf_num();

    if(int($cur_lsf_num) >int($lsf_max) ){
        my $wait_cmd="sleep 180";
        print "left test num:$left_test_num;wait thread  to finish: $cur_lsf_num; $wait_cmd\n";
        `$wait_cmd`;
        return 0;
    }
    else{
        print "current lsf number OK: $cur_lsf_num lsf_max:$lsf_max;left test num:$left_test_num;\n";
        return 1;
    }
}
sub sub_job{

        &run_test($testname,$option);
        print "Waiting!\n";
        `sleep 1`;
}

sub get_licensed_failed{
    my @lines= `grep  "License checkout failure" $ENV{WORKAREA}/test/vcs_run.log -r `;
    my @test=();
    foreach my $line(@lines){
        if($line=~/(\w+)\/vcs_run.log:/){
            push @test,$1;
            print "$1\n";

        }
    }
    return @test;
}
