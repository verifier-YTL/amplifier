#!/usr/bin/perl -w
#******************************************************************************
#   Copyright   : xbj Reserved
#   File        : rpt.pl
#   Author      : xbj 
#   Modified    : 22-12-19 Created
#******************************************************************************
@tc_logs =`ls  tc_*/vcs_run.log`;
#;print "@tc_logs\n";

@prt=();
#RUNNING
$test ="";
foreach $tc_logs(@tc_logs){
    #get test name
    chomp($tc_logs);
    if($tc_logs=~/(\w+)\/vcs_run.log/){
        $test =$1; 
    }
    else{
        print"ERROR: to fiind test name:$tc_logs\n";
        push @prt,"ERROR: to fiind test name:$tc_logs\n";
        exit;
    }

    #check log exit or not
    $ll_info =`ls -l $tc_logs `;
    if($ll_info=~/-> (\S+\.log)/){
        $log_path =$1;
        if(!-e $log_path){
            print "not exist file: $tc_logs $log_path \n";
            print "FAIL NOCHECK log $test  \n";
            push @prt,"FAIL NOCHECK log: $test  \n";
            next;
        }
    }

    $pass_flg =`grep "MVP TEST PASSED"  $tc_logs `;
    $fail_flg =`grep "MVP TEST FAILED"  $tc_logs `;

    if(($pass_flg ne "") and ($fail_flg eq "")){
        print "PASS TEST: $test PASS \n";
        push @prt,"PASS TEST: $test PASS \n";
        
        #;$log_path=`ls -l $tc_logs `;
        #;if($log_path =~/-> \S+\/(\w+\.log)/){
        #;    $log_name =$1;
        #;    #print "cd $test/;/usr/bin/tar -czvf $log_name.tar.gz $log_name \n";
        #;    `cd $test/;/usr/bin/tar -czvf $log_name.tar.gz $log_name;rm -rf $log_name; cd ../ `;
        #;}
    }
    elsif(($fail_flg ne "") and ($pass_flg eq "")){
        $err_log=`grep  "chk fail" $tc_logs`;
        print "FAIL TEST: $test FAIL $err_log \n";
        push @prt,"FAIL TEST: $test FAIL $err_log \n";
    }
    else{
        print "RUNNING TEST: $test RUNNING \n";
        push @prt,"RUNNING TEST: $test RUNNING \n";
    }
}

    open(FIN,">/tool/project/axi/out/test/rpt_1009.log");   
    foreach $prt(sort @prt){
        print FIN "$prt";
    }
    close(FIN);	
