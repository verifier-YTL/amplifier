#!/usr/bin/env python
#******************************************************************************
#   Copyright   : xbj Reserved
#   File        : xb.py
#   Author      : xbj 
#   Modified    : 22-12-19 Created
#******************************************************************************
import os
import sys
import argparse
import random
class xbj(object):
    'EDA simulation run and regression class'
    def __init__(self):
        self.all_cmd      = ['compile','compile_tb','compile_rtl','batch_run','run','ncrun','all','clean','clean_blk','clean_all','verdi', 'regr']
        #print(vars(args))
        self.__dict__.update(vars(args))
        self.workarea     = ''
        self.blklevel     = ''
        self.mdlname      = ''
        self.workpath     = ''
        self.makepath     = ''
        #self.tmppath      = ''
        self.outpath      = ''
        self.makefile     = ''
        self.seedfile     = ''
        self.lsf_cmd      = "bsub  -Is"

    def colorize(self,text,color_code):
        print("\033[{};1m{}\033[0m".format(color_code,text))

    def red(self,text):
        self.colorize(text,31)

    def green(self,text):
        self.colorize(text,32)

    def blue(self,text):
        self.colorize(text,34)

    def gen_path(self):
        self.workarea = self.check_env('WORKAREA')
        self.makepath = os.path.join(self.workarea,'tb')
        self.outpath  = os.path.join(self.workarea,'out')
        self.makefile = os.path.join(self.makepath,'Makefile')
        self.workpath = os.path.join(self.workarea,'dv',self.blklevel,self.mdlname)
        os.system("make -f {mk} create_out".format(mk=self.makefile))
        buildname = self.blklevel+'_'+self.mdlname


    def check_env(self,envname):
        if  os.getenv(envname) is None:
            self.red("[xbj][ERROR]: Please execute sop script first!".format(envname))
            sys.exit()
        else:
            return os.getenv(envname)

    def check_cmdline_para(self):
        if self.cmd == 'comp':
            self.cmd ='compile'
        if self.cmd not in self.all_cmd:
           self.blue("[WARN]:user_defined cmd used,Please check: {}".format(self.cmd))




    def main(self):
        self.gen_path()
        os.chdir(self.makepath)
        self.check_cmdline_para()
        make_cmd= " ".join(['make -f',self.makefile, self.cmd])
        if self.no_lsf is True:
            make_cmd = " ".join([make_cmd,'LSF=off'])
        if self.mode is not None:
            make_cmd = " ".join([make_cmd,'MODE={}'.format(self.mode)])
        if self.out is not None:
            make_cmd = " ".join([make_cmd,'OUT={}'.format(self.out)])
        if self.cmd in ['compile','compile_tb','compile_rtl','run','all']:
            if self.cmp_opts is not None:
                make_cmd = " ".join([make_cmd,"CMDLINE_VLOG_OPTS='{}'".format(' '.join(self.cmp_opts))])
            if self.cov is True:
                make_cmd = " ".join([make_cmd,'COV=on'])
            if self.idpdt_cmp is True:
                make_cmd = " ".join([make_cmd,'COMP_ONE=off'])
                if self.tc is not None:
                    make_cmd = " ".join([make_cmd,"TEST_NAME={}".format(self.tc)])
                else: 
                    self.red("[xbj][ERROR]: indpendent compile each testcase mode, test name must be set tc by -t option")
                    sys.exit()
        if self.cmd in ['batch_run','ncrun','run','all']:
            if self.tc is not None:
                make_cmd = " ".join([make_cmd,"TEST_NAME={}".format(self.tc)])
            else:
                self.red("[xbj][ERROR]: test name must be set by -t option")
                sys.exit()
            if self.seed is not None:
                make_cmd = " ".join([make_cmd,'SEED={}'.format(self.seed)])
            if self.verbosity is not None:
                make_cmd = " ".join([make_cmd,'VERBOSITY={}'.format(self.verbosity)])
            if self.run_opts is not None:
                make_cmd = " ".join([make_cmd,"CMDLINE_VCS_RUN_OPTS='{}'".format(' '.join(self.run_opts))])
            if self.gui is True:
                make_cmd = " ".join([make_cmd,'WAVE=fsdb'])
                make_cmd = " ".join([make_cmd,'GUI=on'])
            if self.cfg is not None:
                make_cmd = " ".join([make_cmd,"CFG={}".format(self.cfg)])
            if self.random is True:
                make_cmd = " ".join([make_cmd,'RANDOM=on'])
            if self.dump is True:
                make_cmd = " ".join([make_cmd,'WAVE=fsdb'])
            if self.mem is True:
                make_cmd = " ".join([make_cmd,'MEM=on'])
            if self.sva is True:
                make_cmd = " ".join([make_cmd,'SVA=on'])
            if self.cmd in ['batch_run','ncrun']:
                if self.cov is True:
                    make_cmd = " ".join([make_cmd,'COV=on'])
                if self.idpdt_cmp is True:
                    make_cmd = " ".join([make_cmd,'COMP_ONE=off'])
        if self.cmd in ['regr']:
            make_cmd = " ".join([make_cmd,'NODE_NO={}'.format(self.node)])
            if self.gui is True:
                make_cmd = " ".join([make_cmd,'GUI=on'])
            if self.emc is not None:
                make_cmd = " ".join([make_cmd,'EMC_NAME={}'.format(self.emc)])
            if self.hvp is not None:
                make_cmd = " ".join([make_cmd,'HVP_NAME={}'.format(self.hvp)])
            if self.tags is not None:
                make_cmd = " ".join([make_cmd,'TAGS={}'.format(self.tags)])
        if self.cmd in ['verdi']:
            if self.cmp_opts is not None:
                make_cmd = " ".join([make_cmd,'CMDLINE_VLOG_OPTS={}'.format(' '.join(self.cmp_opts))])
            if self.tc is not None:
                make_cmd = " ".join([make_cmd,"TEST_NAME={}".format(self.tc)])
            if self.cfg is not None:
                make_cmd = " ".join([make_cmd,"CFG={}".format(self.cfg)])
            if self.idpdt_cmp is True:
                make_cmd = " ".join([make_cmd,'COMP_ONE=off'])
            if self.seed is not None:
                make_cmd = " ".join([make_cmd,'SEED={}'.format(self.seed)])
            else:
                if os.path.exists(self.seedfile):
                    with open(self.seedfile,'r') as f:
                        self.seed=int(f.read())
                    make_cmd =" ".join([make_cmd,'SEED={}'.format(self.seed)])

        if self.no_kdb is True:
             make_cmd = " ".join([make_cmd,'KDB=off'])
        if self.make_opts is not None:
             make_cmd = " ".join([make_cmd,'{}'.format(' '.join(self.make_opts))])
        self.blue("[xbj][INFO]:"+make_cmd)
        os.system(make_cmd)
        self.blue("[xbj][INFO]:"+make_cmd)

usage_help='''xbj <cmd> [options]
cmd    :position arguments, Makefile target
options:optional arguments, Makefile control variable

example:
	xbj compile -co +define+xxx +define+yyy
	xbj run -d  -t tc_sanity -co +define+xxx -ro +a=1 +b=2
	xbj verdi   -t tc_sanity
	xbj regr    --emc *.emc --hvp *.xbj
	...
'''
cmd_help='''
compile_rtl     :Compile RTL only.
compile_tb      :Compile TB only.
comp/compile    :Compile RTL and TB files.
batch_run       :Run simulation only.
ncrun           :pre_run + batch_run + post_run, default pre_run/post_run do nothing
run             :compile + ncrun.
all             :clean_blk + run.
verdi           :open verdi by -t testname,-s seed,-s is optional,load wave if wave exists,load rc if rc exists
regr            :regression
clean           :Delete the temporary files, like log/waves under out directory
clean_blk       :Delete current module out forder,including regression/coverage/build/test temporary files
clean_all       :Delte the whole out folder,including regression/coverage/build/test temporary files
...             :support other makefile target,but optional arguments unavailable
'''
if __name__=='__main__':
    parser = argparse.ArgumentParser(description=usage_help,formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('cmd',help=cmd_help)
    parser.add_argument('-d','--dump',action='store_true',help='dump waveform option')
    parser.add_argument('-c','--cov',action='store_true',help='enable vcs coverage option')
    parser.add_argument('-r','--random',action='store_true',help='gen new random seed simulation,default use last.seed')
    parser.add_argument('-g','--gui',action='store_true',help='use verdi gui debug')
    parser.add_argument('-t','--tc',default=None,metavar='testcase',help='testcase name')
    parser.add_argument('-s','--seed',type=int,metavar='seed',help='testcase seed')
    parser.add_argument('-v','--verbosity',metavar='verbosity',help='testbench display verbosity,default=UVM_LOW')
    parser.add_argument('-co','--cmp_opts',nargs='+',metavar='option',help='testcase compile time option')
    parser.add_argument('-ro','--run_opts',nargs='+',metavar='option',help='testcase run time option')
    parser.add_argument('-mo','--make_opts',nargs='+',metavar='option',help='user define makefile option')
    parser.add_argument('-nk','--no_kdb',action='store_true',help='use filelist mode open verdi')
    parser.add_argument('-nl','--no_lsf',action='store_true',help='do not use lsf cmd,default use lsf cmd:bsub')
    parser.add_argument('-ic','--idpdt_cmp',action='store_true',help='independent compile each testcase')
    parser.add_argument('-cfg','--cfg',metavar='cfg',help='the cfg of testcase,must in test/testcase directory')
    parser.add_argument('-mem','--mem',action='store_true',help='dump mda waveform enable')
    parser.add_argument('-sva','--sva',action='store_true',help='dump sva waveform enable')
    parser.add_argument('-n','--node',type=int,default=50,metavar='num',help='the number of parrallel runs for regression')
    parser.add_argument('-emc','--emc',metavar='*.emc',help='regression emc file')
    parser.add_argument('-hvp','--hvp',metavar='*.hvp',help='regression hvp file')
    parser.add_argument('-tags','--tags',metavar='tag',help='regression tags')
    parser.add_argument('-mode','--mode',metavar='mode',help='for multi mode testbench,default=default')
    parser.add_argument('-out','--out',metavar='out',help='for multi out testbench,default=default')
    args = parser.parse_args()
    kwargs=(vars(args))
    xbj = xbj()
    xbj.main()
