import sys
import re
import os
import argparse
import logging
from datetime import datetime
import subprocess

def findtxt(path, stack1, ret, a):
  stack=[]
  stack.append(path)
  while len(stack) != 0:
    dirPath = stack.pop()
    fileList = os.listdir(dirPath)
    for fileName in fileList:
      fileAbsPath = os.path.join(dirPath, fileName)
      if os.path.isdir(fileAbsPath):
        stack1.append(fileAbsPath)
        #print("111:{}".format(fileAbsPath))
      else:
        if fileAbsPath.startswith(a):
          ret.append(fileAbsPath)
        else:
          pass


class Modify_File_Info():
  def __init__(self,stack):
    self.stack = stack
    self.num = 0

  def parse_file(self):
    #print("33:{}".format(self.stack[0][2::1])) # ./tc_wwdg_hw_test_224929531
    #for i in self.stack:
    num = len(self.stack)
    li_pass = []
    li_fail = []
    li_ongoing = []
    li_n =[]
    for i in range(0, num):
      c=os.path.join("grep -nir 'jvp test pass' .", self.stack[i][2::1])
      b=os.system(c)
      if b==0:
        li_pass.append(self.stack[i][2::1])
     
    for i in range(0, num):
      c=os.path.join("grep -nir 'jvp test fail' .", self.stack[i][2::1])
      b=os.system(c)
      if b==0:
        li_fail.append(self.stack[i][2::1])

    for i in range(0, num):
      c=os.path.join("grep -nir 'jvp test fail' .", self.stack[i][2::1])
      d=os.system(c)
      if d==256:
        print("44:{},i:{}".format(d,i))
        li_n.append(i)
     
    for i in li_n:
      c=os.path.join("grep -nir 'jvp test pass' .", self.stack[i][2::1])
      d=os.system(c)
      if d==256:
        li_ongoing.append(self.stack[i][2::1])

    print(li_pass)
    print(li_fail)
    print(li_ongoing)

    with open("rpt.log", "w") as f:
      for i in range(0, len(li_ongoing)):
        f.write(li_ongoing[i])
        f.write("         ongoing\n")

      for i in range(0, len(li_fail)):
        f.write(li_fail[i])
        f.write("         fail\n")

      for i in range(0, len(li_pass)):
        f.write(li_pass[i])
        f.write("         pass\n")

def main():
  root=r"./"
  ret=[]
  stack=[]
  #a = raw_input("Please input the case name, \nfor example: tc_wwdg_reg_test\n")
  a = "tc_wwdg_reg_test" 
  print("Please be patient, it will soon finish!")

  findtxt(root,stack, ret, a)
  mfti = Modify_File_Info(stack)
  mfti.parse_file()

main()
		
